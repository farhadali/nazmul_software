
<style type="text/css">
 


 #header {
    display
<style type="text/css">
 


 #header {
    display:table-header-group;
}
#footer {
    display:table-footer-group;
  
} 
  @media print {
  #footer {
    position: fixed;
    bottom: 0;
  }
}
  table{
    font-size:11px;
  }
  
    </style>
<div style="float:right">
  <div class="ewExportOption ewListOptionSeparator" style="white-space: nowrap;" data-name="button">
  <div class="btn-group ewButtonGroup">
    <a class="btn btn-default ewExportLink ewPrint" title="" data-caption="Print" id="print_62" onclick="javascript:printDiv('printablediv')"
    data-original-title="Print"><span data-phrase="PrinterFriendly" class="icon-print ewIcon" data-caption="Print"></span></a>
   
     </div>
</div>

  <script>
        function myFunction() {
            window.print();
        }

    </script>
  </div>
<div id="printablediv" style="width:100%;margin-top:0px;">
  <div style="width:100%;">
    <div class="_header_area" style="text-align:center;width:100%;">
    
      <img style=' vertical-align: center;height:40px'  />
  
    <p>
      Address
    </p>
    <p>
      Phone
    </p>
    </div>
  
    <div class="_sub_head_area" style="width:100%;">
      <div style="width:33%;float:left;text-align:left">
          
    <p>GOVERNMENT LICENSE NO:<b>5297</b></p>
    <p>GLMCL ID:<b>21432431</b></p>
      </div>
      <div style="width:33%;float:left;text-align:center">
        <img style='width: 100%; vertical-align: center;height:60px'  /><br>
        <h4 style="text-align: center !important;">CANDIDATE INFORMATION</h4>
      </div>
      <div style="width:33%;float:left;text-align:right">
        <p>Examined Date:<b>_dateofexamined</b></p>
        <p>Expiry Date:<b>reportexpirydate</b></p>
        
      </div>
      
    </div>
    
    <div style="clear: both;"></div>
    <div class="_personal_information" style="width:100%;">
      <div style="width:30%;float:left;text-align:left;">
        <p>Name:<b>_name</b></p>
        <p>Gender:<b>_gender</b></p>
        <p>Marital Status:<b>_maritalstatus</b></p>
        <p>Traveling To :<b>_country_name</b></p>
        <p>Profession:<b>_profession</b></p>
        
      </div>
      <div style="width:30%;float:left;text-align:left;">
        <p>Age:<b>_age</b></p>
        <p>Date of birth:_dateofbirth</p>
        <p>Nationality:<b>_nationality</b></p>
        <p>Visa No:<b>_visano</b></p>
        <p>Visa Date:<b>_visadate</b></p>
        
      </div>
      <div style="width:30%;float:left;text-align:left;">
        <p>Weight:<b>_weight</b></p>
        <p>Height:<b>_height</b></p>
        <p>Place of Issue:<b>_place</b></p>
        <p>Weight:<b>_weight</b></p>
      </div>
      <div style="width:10%;float:left;text-align:right;">
        <img style='width: 100px; height: 100px; vertical-align: top;padding: 1px;'  /><br>
        <b>_passportnumber</b>
      </div>
    </div>
    <div style="clear: both;"></div>
    <div class="_personal_information" style="width:100%;">
      <p><span style="font-size:12px;">HISTORY OF ANY SIGNIFICANT PAST ILLNESS INCLUDING:1. ALLERGY: <strong>NIL</strong> 2.OTHERS:<strong>NAD</strong>,3.PSYCHIATRIC AND NEUROLOGICAL DISORDERS: <strong>NIL</strong><br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I HEREBY PERMIT THE: GREENLAND MEDICAL CENTRE LTD. AND THE UNDERSIGNED PHYSICAN TO FURNISH SUCH INFORMATION THE COMPANY
    MAY NEED PERTAINING TO MY HEALTH STATUS AND OTHER PERTINENT AND MEDICAL FINDINGS AND DO HEREBY RELEASE THEM FROM ANY ALL LEGAL
      RESPONSIBILITY BY DOING SO. I ALSO CERTIFY THAT MY MEDICAL HISTORY CONTAINED ABOVE IS TRUE AND ANY FALSE STATEMENT WILL DISQUALIFY
    ME FROM MY EMPLOYMENT, BENEFITS AND CLAIMS.</span></p>
    </div>
    <div style="clear: both;"></div>
    <div style="width:100%;">
      <div style="width:50%;float:left;">
        <h5 style="text-align:center;">MEDICAL EXAMINATION</h5>
  
      <div style="width:100%;">
        
        <div style="width:100%;">
      <table style="width:100%;">
        <div style="width:50%;float:left;text-align:left;">
          <p><b>TYPE OF EXAMINATION</b></p>
        </div>
        <div style="width:40%;float:left;text-align:center;">
          <p><b>RESULT</b></p>
        </div>
      
        <tr>
          <td style="width:60%;"><p style="margin-top:40px;">REMARKS:</p>
            <p>DEAR SIR/MADAM,</p>
          </td>
          

          <td style="width:40%;"><div  style="text-align: center;height: 90px;width: 110px;margin-left:50px;">  
   
</div></td>
        </tr>
        <tr>
      <td colspan="2" >
            
            
            MENTIONED ABOVE IS THE MEDICAL REPORT FOR<br>
             WHO IS <b style="font-size:26px;"></b> FOR THE ABOVE MENTIONED JOB.


          </td>
          
        </tr>
        
      </table>
    </div>
      </div>
      </div>
      <div style="width:50%;float:left;">
        <h5 style="text-align:center;">LABORATORY INVESTIGATION</h5>
        <div style="width:100%;">
        
        
    <div style="width:100%">
      <table style="width:100%;">
        <tr>
          <td style="text-align:left;"><b>TYPE OF LAB INVESTIGATION</b></td>
          <td style="text-align:left;"><b>RESULT</b></td>
        </tr>
        
      </table>
    </div>
      </div>
      </div>
      
    </div>
    <div style="width:100%;">
      <table style="width:100%;">
        
        
        <tr>
          <td  style="text-align:left;">
            <p style="margin-top:30px;"><b>CHIEF PHYSICIAN</b><p>
            <p>NAME:........................................</p>
          </td>
          <td  style="text-align:right;">
            <p><b>SIGNATURE</b>............................................</p>
          </td>
        </tr>
      </table>
    </div>
    
  </div>
  
</div>



<script>
  function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML =
                "<html><head><title></title></head><body>" +
                divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;


        }

  
  
</script>
:table-header-group;
}
#footer {
    display:table-footer-group;
	
} 
	@media print {
  #footer {
    position: fixed;
    bottom: 0;
  }
}
	table{
		font-size:11px;
	}
	
    </style>
<div style="float:right">
	<div class="ewExportOption ewListOptionSeparator" style="white-space: nowrap;" data-name="button">
  <div class="btn-group ewButtonGroup">
    <a class="btn btn-default ewExportLink ewPrint" title="" data-caption="Print" id="print_62" onclick="javascript:printDiv('printablediv')"
    data-original-title="Print"><span data-phrase="PrinterFriendly" class="icon-print ewIcon" data-caption="Print"></span></a>
	 
     </div>
</div>

	<script>
        function myFunction() {
            window.print();
        }

    </script>
	</div>
<div id="printablediv" style="width:100%;margin-top:0px;">
	<div style="width:100%;">
		<div class="_header_area" style="text-align:center;width:100%;">
		
			<img style=' vertical-align: center;height:40px'  />
	
		<p>
		  Address
		</p>
		<p>
		  Phone
		</p>
		</div>
	
		<div class="_sub_head_area" style="width:100%;">
			<div style="width:33%;float:left;text-align:left">
					
		<p>GOVERNMENT LICENSE NO:<b>5297</b></p>
		<p>GLMCL ID:<b>21432431</b></p>
			</div>
			<div style="width:33%;float:left;text-align:center">
				<img style='width: 100%; vertical-align: center;height:60px'  /><br>
				<h4 style="text-align: center !important;">CANDIDATE INFORMATION</h4>
			</div>
			<div style="width:33%;float:left;text-align:right">
				<p>Examined Date:<b>_dateofexamined</b></p>
				<p>Expiry Date:<b>reportexpirydate</b></p>
				
			</div>
			
		</div>
		
		<div style="clear: both;"></div>
		<div class="_personal_information" style="width:100%;">
			<div style="width:30%;float:left;text-align:left;">
				<p>Name:<b>_name</b></p>
				<p>Gender:<b>_gender</b></p>
				<p>Marital Status:<b>_maritalstatus</b></p>
				<p>Traveling To :<b>_country_name</b></p>
				<p>Profession:<b>_profession</b></p>
				
			</div>
			<div style="width:30%;float:left;text-align:left;">
				<p>Age:<b>_age</b></p>
				<p>Date of birth:_dateofbirth</p>
				<p>Nationality:<b>_nationality</b></p>
				<p>Visa No:<b>_visano</b></p>
				<p>Visa Date:<b>_visadate</b></p>
				
			</div>
			<div style="width:30%;float:left;text-align:left;">
				<p>Weight:<b>_weight</b></p>
				<p>Height:<b>_height</b></p>
				<p>Place of Issue:<b>_place</b></p>
				<p>Weight:<b>_weight</b></p>
			</div>
			<div style="width:10%;float:left;text-align:right;">
				<img style='width: 100px; height: 100px; vertical-align: top;padding: 1px;'  /><br>
				<b>_passportnumber</b>
			</div>
		</div>
		<div style="clear: both;"></div>
		<div class="_personal_information" style="width:100%;">
			<p><span style="font-size:12px;">HISTORY OF ANY SIGNIFICANT PAST ILLNESS INCLUDING:1. ALLERGY: <strong>NIL</strong> 2.OTHERS:<strong>NAD</strong>,3.PSYCHIATRIC AND NEUROLOGICAL DISORDERS: <strong>NIL</strong><br>
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I HEREBY PERMIT THE: GREENLAND MEDICAL CENTRE LTD. AND THE UNDERSIGNED PHYSICAN TO FURNISH SUCH INFORMATION THE COMPANY
		MAY NEED PERTAINING TO MY HEALTH STATUS AND OTHER PERTINENT AND MEDICAL FINDINGS AND DO HEREBY RELEASE THEM FROM ANY ALL LEGAL
	    RESPONSIBILITY BY DOING SO. I ALSO CERTIFY THAT MY MEDICAL HISTORY CONTAINED ABOVE IS TRUE AND ANY FALSE STATEMENT WILL DISQUALIFY
		ME FROM MY EMPLOYMENT, BENEFITS AND CLAIMS.</span></p>
		</div>
		<div style="clear: both;"></div>
		<div style="width:100%;">
			<div style="width:50%;float:left;">
				<h5 style="text-align:center;">MEDICAL EXAMINATION</h5>
	
			<div style="width:100%;">
				
				<div style="width:100%;">
			<table style="width:100%;">
				<div style="width:50%;float:left;text-align:left;">
					<p><b>TYPE OF EXAMINATION</b></p>
				</div>
				<div style="width:40%;float:left;text-align:center;">
					<p><b>RESULT</b></p>
				</div>
			
				<tr>
					<td style="width:60%;"><p style="margin-top:40px;">REMARKS:</p>
						<p>DEAR SIR/MADAM,</p>
					</td>
					

					<td style="width:40%;"><div  style="text-align: center;height: 90px;width: 110px;margin-left:50px;">  
   
</div></td>
				</tr>
				<tr>
			<td colspan="2" >
						
						
						MENTIONED ABOVE IS THE MEDICAL REPORT FOR<br>
						 WHO IS <b style="font-size:26px;"></b> FOR THE ABOVE MENTIONED JOB.


					</td>
					
				</tr>
				
			</table>
		</div>
			</div>
			</div>
			<div style="width:50%;float:left;">
				<h5 style="text-align:center;">LABORATORY INVESTIGATION</h5>
				<div style="width:100%;">
				
				
		<div style="width:100%">
			<table style="width:100%;">
				<tr>
					<td style="text-align:left;"><b>TYPE OF LAB INVESTIGATION</b></td>
					<td style="text-align:left;"><b>RESULT</b></td>
				</tr>
				
			</table>
		</div>
			</div>
			</div>
			
		</div>
		<div style="width:100%;">
			<table style="width:100%;">
				
				
				<tr>
					<td  style="text-align:left;">
						<p style="margin-top:30px;"><b>CHIEF PHYSICIAN</b><p>
						<p>NAME:........................................</p>
					</td>
					<td  style="text-align:right;">
						<p><b>SIGNATURE</b>............................................</p>
					</td>
				</tr>
			</table>
		</div>
		
	</div>
	
</div>



<script>
	function printDiv(divID) {
            //Get the HTML of div
            var divElements = document.getElementById(divID).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML =
                "<html><head><title></title></head><body>" +
                divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;


        }

	
	
</script>
